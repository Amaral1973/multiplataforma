<?php
include 'conecta.php';
$nome = $_POST["nome"];
$turno = $_POST["turno"];
$depto = $_POST["departamento"];


if (!isset($nome)) {
    echo "<script language='javascript' type='text/javascript'>
        alert('Por favor, digite todos os campos!');
        window.location.href='index.php';
        </script>";
}
$sql = "INSERT INTO funcionario(nome,turno,depto) VALUES ('$nome','$turno','$depto')";
if (mysqli_query($conn, $sql)) {
    echo "<script language='javascript' type='text/javascript'>
        window.location.href='index.php';
        </script>";
}
mysqli_close($conn);
