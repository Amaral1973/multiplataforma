<?php
    include 'conecta.php';
    $id = $_GET['id'];
    $nome = $_POST['nome'];
    $turno = $_POST['turno'];
    $depto = $_POST['depto'];
    $sql = "UPDATE funcionario SET nome=?,turno=?,depto=? WHERE id=?";
    $pes = $conn->prepare($sql) or die($conn->error);
    if (!$pes) {
        echo "Erro:".$conn->error;
    }
    $pes->bind_param('sssi',$nome,$turno,$depto,$id);
    $pes->execute();
    $pes->close();
    header("Location: index.php");
?>